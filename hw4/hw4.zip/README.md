# hw4RakaminFSWD

Hallo kali ini saya telah mengerjakan tugas minggu ke 4 pada Bootcamp Rakamin Full Stack Web Development
Sempat Kesulitan pada awal pengerjaan, namun dengan berusaha belajar dan bertanya serta bantuan asisten tutor serta teman-teman semua, akhirnya tugas saya bisa diselesaikan dengan baik
Terimakasih, masukan dan saran sangat merarti bagi saya
