const calcsoal1 = require("./calcsoal1.js");

// Luas dan keliling Persegi dengan sisi = 10
console.log("Luas Persegi adalah " + calcsoal1.luas(10, 10));
console.log("Keliling Persegi adalah " + calcsoal1.keliling(10, 10));

// Luas dan keliling Persegi Panjang dengan Panjang = 10 Lebar = 5
console.log("Luas Persegi Panjang adalah " + calcsoal1.luas(10, 5));
console.log("Keliling Persegi Panjang adalah " + calcsoal1.keliling(10, 5));
