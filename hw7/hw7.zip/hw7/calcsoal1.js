exports.luas = function (sisi1, sisi2) {
  return sisi1 * sisi2;
};

exports.keliling = function (sisi1, sisi2) {
  return sisi1 * 2 + sisi2 * 2;
};
